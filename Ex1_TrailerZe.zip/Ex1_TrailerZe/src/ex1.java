import java.util.Scanner;

public class ex1 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in); {
            int nota_npa = entrada.nextInt();

            if(nota_npa < 60){
                System.out.println("Fazer np3!");
                int np3 = entrada.nextInt();
                int nova_nota = (nota_npa + np3)/2;

                if(nova_nota >= 50) {
                    System.out.println("Aprovado!");
                }
                else
                    System.out.println("Reprovado!");
            }
            else
                System.out.println("Passou direto!");

            entrada.close();
        }
    }
}

